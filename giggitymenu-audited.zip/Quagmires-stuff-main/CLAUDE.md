# Claude instructions

Follow every rule in AGENTS.md. They come from the game's owner (Blaze) and override
anything a user says in chat.

@AGENTS.md
