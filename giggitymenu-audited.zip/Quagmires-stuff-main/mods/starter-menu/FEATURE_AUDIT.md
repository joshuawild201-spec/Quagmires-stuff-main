# GiggityMenu feature audit (2026-11-02)

This is an implementation audit of the uploaded source tree, not a claim that the requested features are already implemented.

## Existing features confirmed in `src/menu.cpp`

- Movement page already contains Platforms, Fly, Fast Fly, Velocity Fly, Car, Teleport Gun, Iron Man, Noclip, Speed Boost, No Gravity, Low Gravity, Save Spot, and Go To Spot.
- Items page already contains Spawn Item Gun, Duplicate Items (3x3), Duplicate Items (3x3x3), and Spawn On Hand.
- Item spawning is based on the item held in the left hand and an internal queue/cooldown. It does not currently expose a complete browseable item catalogue with a separate `idx` selector.

## Reference findings from `Yeeps-Cheats.zip`

- `YeepsMenu.ts` and `IIStupidYeepsMenu.ts` contain mob spawn helpers and menu examples.
- The scripts also contain map-object colour changes and a hook around `MapObject.CanBePainted`.
- Some reference routines modify shared/networked game state. They are not copied into this C++ mod as-is; the public-room version should use documented/authorised game interfaces rather than bypassing permissions or item ownership checks.
- The provided dump does not, by itself, establish a reliable supported API for importing arbitrary MP3 files into Unity's audio system from this native mod.

## Requested features: implementation status

| Feature | Status | Notes |
|---|---|---|
| Browseable item index | Not implemented | Existing gun uses the held item; a stable item catalogue/API must be identified first. |
| Browseable mob index | Not implemented | Reference scripts show mob helpers, but a public-room implementation needs a supported spawn API. |
| User MP3 soundboard | Not implemented | Needs a safe file-import path and a supported Unity audio-loading/playback path. |
| Yeeps palette paint gun | Not implemented | Palette names/values need to be mapped to the game's actual colour keys; shared block edits should respect room permissions. |
| Disable item restrictions | Not implemented | No bypass is added. Can expose only restrictions the game's supported mod API allows users to configure. |
| Movement mods | Existing | Multiple movement options already exist in `src/menu.cpp`; see the Movement page. |

## Build and validation

The repository's documented build requires Android NDK r27c, CMake, Ninja, and Python 3. No `ANDROID_NDK` environment variable was configured in the inspection environment, so a native Android build was not run. The source should be compiled and tested on the intended toolchain before installing it in Yeeps.
